import os
import sys

os.system("start cmd /c pip install pygame")

try:
    import pygame
    os.startfile('Mario_Kart_Remastered_Intro_Screen.py')
except:
    os.startfile('pygame_install.txt')
